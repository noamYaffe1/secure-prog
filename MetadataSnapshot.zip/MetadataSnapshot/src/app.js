const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const metadataRoutes = require('./routes/metadata');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Routes
app.use('/api/metadata', metadataRoutes);

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Internal server error' });
});

app.listen(port, () => {
    console.log(`MetadataSnapshot service running on port ${port}`);
}); 