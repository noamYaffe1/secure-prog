const axios = require('axios');
const cheerio = require('cheerio');
const UrlValidator = require('./urlValidator');

class MetadataExtractor {
    constructor() {
        this.urlValidator = new UrlValidator();
        
        this.axiosConfig = {
            timeout: 5000,
            maxRedirects: 5,
            validateStatus: null
        };
    }

    async extractMetadata(url) {
        if (!this.urlValidator.isValidUrl(url)) {
            throw new Error('Invalid URL provided');
        }

        try {
            const response = await axios.get(url, this.axiosConfig);

            const $ = cheerio.load(response.data);

            const metadata = {
                title: $('title').text(),
                description: $('meta[name="description"]').attr('content'),
                ogTitle: $('meta[property="og:title"]').attr('content'),
                ogDescription: $('meta[property="og:description"]').attr('content'),
                ogImage: $('meta[property="og:image"]').attr('content'),
                headers: response.headers,
                statusCode: response.status
            };

            return metadata;
        } catch (error) {
            throw new Error(`Failed to fetch metadata: ${error.message}`);
        }
    }

    async checkUrlAvailability(url) {
        try {
            const response = await axios.head(url, {
                ...this.axiosConfig,
                timeout: 2000
            });
            return { available: true, status: response.status };
        } catch (error) {
            return { available: false, error: error.message };
        }
    }
} 