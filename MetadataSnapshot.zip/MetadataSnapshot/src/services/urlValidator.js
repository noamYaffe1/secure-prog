const URL = require('url');

class UrlValidator {
    constructor() {
        // Protocol denylist
        this.blockedProtocols = ['file:', 'ftp:'];
        
        // IP address and domain denylist
        this.blockedDomains = [
            'localhost',
            '127.0.0.1',
            'internal'
        ];
    }

    isValidUrl(urlString) {
        try {
            const parsedUrl = new URL.URL(urlString);
            
            // Protocol check
            if (this.blockedProtocols.includes(parsedUrl.protocol.toLowerCase())) {
                return false;
            }

            const hostname = parsedUrl.hostname.toLowerCase();
            
            if (this.blockedDomains.some(domain => hostname.includes(domain))) {
                return false;
            }

            return true;
        } catch (error) {
            return false;
        }
    }

    isValidRedirect(redirectUrl) {
        return this.isValidUrl(redirectUrl);
    }

    extractHostname(urlString) {
        try {
            const parsedUrl = new URL.URL(urlString);
            return parsedUrl.hostname;
        } catch {
            return null;
        }
    }
} 