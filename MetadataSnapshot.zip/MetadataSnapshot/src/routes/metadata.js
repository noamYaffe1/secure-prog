const express = require('express');
const { body, validationResult } = require('express-validator');
const MetadataExtractor = require('../services/metadataExtractor');

const router = express.Router();
const metadataExtractor = new MetadataExtractor();

// Validate URL middleware
const validateUrl = [
    body('url')
        .isURL()
        .withMessage('Invalid URL format')
        .trim(),
];

router.post('/extract', validateUrl, async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const metadata = await metadataExtractor.extractMetadata(req.body.url);
        res.json(metadata);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

router.get('/check', async (req, res) => {
    const { url } = req.query;
    
    if (!url) {
        return res.status(400).json({ error: 'URL is required' });
    }

    try {
        const result = await metadataExtractor.checkUrlAvailability(url);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 