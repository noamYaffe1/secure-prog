# Robust SSRF & Metadata Protection Solution

## Affected Files
- `src/services/urlValidator.js`
- `src/services/metadataExtractor.js`
- `src/routes/metadata.js`

## Vulnerability Summary
The current implementation only blocks a few protocols and domains, making it vulnerable to:
- Bypasses using encoded/obfuscated IPs (e.g., octal, hex, dword, IPv6)
- DNS rebinding and hostnames resolving to internal IPs
- Access to cloud metadata endpoints (e.g., AWS, GCP, Azure)
- Port scanning and non-standard ports
- Insecure redirect handling

## Example Attack Flow

### 1. Accessing Internal Network (SSRF)

**Attack:**
```http
POST /api/metadata/extract
Content-Type: application/json

{
    "url": "http://10.0.0.1:8080/admin"
}
```
**Impact:** Attacker can access internal admin panels or services not meant to be exposed.

**Mitigation:** The improved solution resolves the hostname, checks all IPs against a CIDR blocklist, and blocks the request.

---

### 2. Cloud Metadata Service Access

**Attack:**
```http
POST /api/metadata/extract
Content-Type: application/json

{
    "url": "http://169.254.169.254/latest/meta-data/"
}
```
**Impact:** Attacker can steal cloud credentials or sensitive metadata.

**Mitigation:** The solution blocks all requests to metadata IPs, including encoded and IPv6 variants.

---

### 3. DNS Rebinding

**Attack:**
```http
POST /api/metadata/extract
Content-Type: application/json

{
    "url": "http://attacker-domain.com"
}
```
Attacker's domain resolves to a public IP, then to an internal IP after initial validation.

**Impact:** Bypass of naive hostname checks, access to internal resources.

**Mitigation:** The solution resolves all IPs for the hostname before any request and blocks if any are internal.

---

### 4. Localhost Access via Encoded IP

**Attack:**
```http
POST /api/metadata/extract
Content-Type: application/json

{
    "url": "http://0177.0.0.1/secret"
}
```
**Impact:** Bypass of string-based localhost checks, access to local resources.

**Mitigation:** The solution uses an IP parsing library to detect and block all representations of localhost.

---

### 5. Port Scanning

**Attack:**
```http
GET /api/metadata/check?url=http://internal-service:22
```
**Impact:** Attacker can scan internal network ports.

**Mitigation:** The solution only allows standard ports (80, 443), blocking port scanning attempts.

## Improved Solution

### 1. Comprehensive URL Validation

- Use an IP address library (e.g., `ipaddr.js`) to parse and check all resolved IPs (including after DNS resolution and redirects).
- Block all internal, private, and metadata IP ranges (IPv4 & IPv6).
- Allow only `http` and `https` protocols.
- Allow only standard ports (80, 443).
- Re-validate after every redirect.

#### Example Implementation

```javascript
const dns = require('dns').promises;
const ipaddr = require('ipaddr.js');

const BLOCKED_CIDRS = [
    '127.0.0.0/8',      // localhost
    '10.0.0.0/8',       // private
    '172.16.0.0/12',    // private
    '192.168.0.0/16',   // private
    '169.254.169.254/32', // AWS/GCP/Azure metadata
    '::1/128',          // IPv6 localhost
    'fc00::/7',         // IPv6 unique local
    'fe80::/10'         // IPv6 link-local
];

function isIpBlocked(ip) {
    const addr = ipaddr.parse(ip);
    return BLOCKED_CIDRS.some(cidr => addr.match(ipaddr.parseCIDR(cidr)));
}

async function isValidUrl(urlString) {
    try {
        const url = new URL(urlString);
        if (!['http:', 'https:'].includes(url.protocol)) return false;
        const port = url.port || (url.protocol === 'https:' ? '443' : '80');
        if (!['80', '443'].includes(port)) return false;

        // Resolve all IPs for the hostname
        const addresses = await dns.lookup(url.hostname, { all: true });
        for (const { address } of addresses) {
            if (isIpBlocked(address)) return false;
        }
        return true;
    } catch {
        return false;
    }
}
```

### 2. Secure HTTP Requests

- Set strict timeouts, limit redirects, and restrict response size.
- Never expose internal error details or headers.
- Only process expected content-types (e.g., `text/html`, `application/json`).

#### Example Axios Config

```javascript
const axiosConfig = {
    timeout: 5000,
    maxRedirects: 2,
    validateStatus: status => status >= 200 && status < 300,
    headers: { 'User-Agent': 'MetadataSnapshot/2.0' },
    maxContentLength: 1024 * 1024,
    withCredentials: false
};
```

### 3. Metadata Endpoint Protection

- Explicitly block requests to `169.254.169.254` and similar metadata endpoints.
- Block all variants (IPv4, IPv6, encoded, etc.).

### 4. Additional Security Measures

- Use a proxy for all outbound requests, with firewall rules.
- Implement rate limiting and logging.
- Sanitize all user input and output.
- Never return raw error messages or stack traces.

## Summary Table

| Threat                | Mitigated? | How?                                 |
|-----------------------|------------|--------------------------------------|
| Internal IP access    | Yes        | CIDR blocklist, IP parsing           |
| Metadata endpoints    | Yes        | Explicit block, CIDR, all encodings  |
| DNS rebinding         | Yes        | Resolve all IPs, block on match      |
| Port scanning         | Yes        | Allowlist ports                      |
| Protocol bypass       | Yes        | Allowlist protocols                  |
| Redirect abuse        | Yes        | Re-validate after redirects          |
| Error leakage         | Yes        | Sanitize errors                      |

## References

- [OWASP SSRF Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html)
- [ipaddr.js](https://github.com/whitequark/ipaddr.js/)