# Reflected XSS Demo Application

This is a Node.js Express application designed for security code review exercises. The app simulates a simple feedback portal with the following features:

- A feedback form that allows users to submit their name and feedback.
- A greeting page that greets the user by name using a cookie.
- Modular code structure with separate routes and a service for input handling (`filterInput`).

The application is intentionally designed for educational purposes and may contain security flaws for review and learning. Please use it in a safe, controlled environment.

## Structure
- `app.js`: Main application entry point.
- `routes/feedback.js`: Handles feedback form submissions.
- `routes/greet.js`: Handles greeting logic.
- `services/sanitizeService.js`: Handles user input processing with `filterInput`.

## Getting Started
1. Install dependencies:
   ```sh
   npm install express body-parser cookie-parser
   ```
2. Start the app:
   ```sh
   node app.js
   ```
3. Visit [http://localhost:3002](http://localhost:3002) in your browser.

## For Reviewers
- Review the code for security issues, especially around user input handling and output.
- See `hint.md` for guidance on where to look.
