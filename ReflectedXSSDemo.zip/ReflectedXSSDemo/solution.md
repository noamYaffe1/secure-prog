# Solution

## Step-by-step Exploit

1. **Locate the Feedback Route**
   - In `routes/feedback.js`, observe the POST `/feedback` endpoint.
   - The endpoint takes `name` and `feedback` from the request body and uses a function from `services/sanitizeService.js` (`filterInput`) before reflecting them in the HTML response.

2. **Review the Input Filtering**
   - In `services/sanitizeService.js`, the `filterInput` function only replaces occurrences of `<script` with `&lt;script`.
   - Other HTML tags and event handlers (e.g., `<img onerror=alert(1)>`) are not filtered or escaped.

3. **Exploit Example**
   - Submit the following as feedback:
     ```
     <img src=x onerror=alert('XSS')>
     ```
   - The response will reflect this input unsanitized, causing the JavaScript to execute in the browser.

4. **Greet Route**
   - In `routes/greet.js`, the `user` cookie is reflected in the response using the same `filterInput` function.
   - Setting the `user` cookie to a payload like `<img src=x onerror=alert('XSS')>` will also trigger XSS when visiting `/greet`.

## Full Solution

- Use a robust HTML escaping library (e.g., `he` or `escape-html`) to encode all user input before rendering it in HTML.
- Example fix for `filterInput`:
  ```js
  const escape = require('escape-html');
  function robustFilterInput(input) {
      return escape(input);
  }
  ```
- Replace all uses of `filterInput` with `robustFilterInput` in the routes.
