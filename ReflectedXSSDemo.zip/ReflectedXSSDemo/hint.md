# Hint

Focus your review on the logic in the `services/sanitizeService.js` file and how the `filterInput` function is used in the feedback and greeting routes. Consider how user input is handled and reflected in the application.
