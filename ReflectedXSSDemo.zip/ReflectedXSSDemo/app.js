const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const feedbackRoute = require('./routes/feedback');
const greetRoute = require('./routes/greet');
const app = express();
const port = 3002;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

app.get('/', (req, res) => {
    res.send(`
        <html>
        <body>
            <h2>Welcome to the Feedback Portal</h2>
            <form method="POST" action="/feedback">
                <label>Name: <input name="name" /></label><br/>
                <label>Feedback: <textarea name="feedback"></textarea></label><br/>
                <button type="submit">Submit</button>
            </form>
            <a href="/greet">Greet Me</a>
        </body>
        </html>
    `);
});

app.use('/feedback', feedbackRoute);
app.use('/greet', greetRoute);

app.listen(port, () => {
    console.log(`Feedback app listening at http://localhost:${port}`);
});
