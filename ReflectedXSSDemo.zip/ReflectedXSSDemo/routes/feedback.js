// routes/feedback.js

const express = require('express');
const router = express.Router();
const { filterInput } = require('../services/sanitizeService');

router.post('/', (req, res) => {
    const name = req.body.name || 'Anonymous';
    const feedback = req.body.feedback || '';
    // Set user cookie (not httpOnly)
    res.cookie('user', name);
    // Simple mitigation: only sanitize <script> tags
    res.send(`
        <html>
        <body>
            <h2>Thank you, ${filterInput(name)}!</h2>
            <p>Your feedback:</p>
            <blockquote>${filterInput(feedback)}</blockquote>
            <a href="/">Back</a>
        </body>
        </html>
    `);
});

module.exports = router;
