// routes/greet.js

const express = require('express');
const router = express.Router();
const { filterInput } = require('../services/sanitizeService');

router.get('/', (req, res) => {
    const user = req.cookies.user || 'Guest';
    res.send(`<html><body><h1>Hello, ${filterInput(user)}!</h1><a href="/">Back</a></body></html>`);
});

module.exports = router;
