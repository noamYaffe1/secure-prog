function filterInput(input) {
    return input.replace(/<script/gi, '&lt;script');
}

module.exports = { filterInput };
