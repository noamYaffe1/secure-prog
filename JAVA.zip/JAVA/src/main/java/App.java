import middleware.SecurityMiddleware;
import routes.Metadata;
import java.time.Instant;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class App {
    private final SecurityMiddleware security;
    private final Metadata metadataRoutes;
    private final int port;

    public App() {
        this.security = new SecurityMiddleware();
        this.metadataRoutes = new Metadata();
        this.port = Integer.parseInt(System.getenv("PORT") != null ? System.getenv("PORT") : "3000");
    }

    public void start() {
        System.out.println("MetadataSnapshot service running on port " + port);
        System.out.println("Environment: " + (System.getenv("NODE_ENV") != null ? System.getenv("NODE_ENV") : "development"));

        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            security.cleanup();
        }, 1, 1, TimeUnit.HOURS);
    }

    public Map<String, Object> handleRequest(String method, String path, String body, String clientIP, String userAgent, long contentLength) {
        Map<String, Object> response = new HashMap<>();
        Map<String, String> headers = new HashMap<>();
        
        security.securityHeaders(headers);
        
        if (!security.limitRequestSize(contentLength, 2048)) {
            response.put("error", "Request too large");
            response.put("status", 413);
            return response;
        }

        security.trackRequest(clientIP, userAgent, extractUrlFromBody(body));

        if ("/health".equals(path) && "GET".equals(method)) {
            response.put("status", "ok");
            response.put("timestamp", Instant.now().toString());
            response.put("service", "MetadataSnapshot");
            response.put("statusCode", 200);
            return response;
        }

        if ("/api/metadata/extract".equals(path) && "POST".equals(method)) {
            String url = extractUrlFromBody(body);
            return metadataRoutes.extract(url, clientIP);
        }

        if (path.startsWith("/api/metadata/check") && "GET".equals(method)) {
            String url = extractUrlFromQuery(path);
            return metadataRoutes.check(url, clientIP);
        }

        response.put("error", "Endpoint not found");
        response.put("status", 404);
        return response;
    }

    public void handleError(Exception error) {
        System.err.println("[" + Instant.now().toString() + "] Error: " + error.getMessage());
        error.printStackTrace();
    }

    private String extractUrlFromBody(String body) {
        if (body == null) return null;
        
        try {
            String[] pairs = body.split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length == 2 && "url".equals(keyValue[0])) {
                    return java.net.URLDecoder.decode(keyValue[1], "UTF-8");
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    private String extractUrlFromQuery(String path) {
        if (path == null || !path.contains("?")) return null;
        
        try {
            String query = path.substring(path.indexOf("?") + 1);
            String[] pairs = query.split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=", 2);
                if (keyValue.length == 2 && "url".equals(keyValue[0])) {
                    return java.net.URLDecoder.decode(keyValue[1], "UTF-8");
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public static void main(String[] args) {
        App app = new App();
        app.start();
    }
}
