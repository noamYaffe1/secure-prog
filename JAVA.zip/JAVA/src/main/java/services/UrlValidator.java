package services;

import java.net.URL;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class UrlValidator {
    private final List<String> blockedProtocols;
    private final List<String> blockedDomains;
    private final List<Pattern> privateIPRanges;
    private final List<Integer> blockedPorts;

    public UrlValidator() {
        this.blockedProtocols = Arrays.asList(
            "file:", "ftp:", "javascript:", "data:", "gopher:",
            "ldap:", "ldaps:", "dict:", "sftp:", "http:"
        );
        
        this.blockedDomains = Arrays.asList(
            "localhost", "localtest", "internal", "intranet",
            "127.0.0.1", "0.0.0.0", "::1", "0:0:0:0:0:0:0:1",
            "169.254.169.254",
            "169.254.169.253",
            "metadata.google.internal",
            "metadata", "instance-data"
        );

        this.privateIPRanges = Arrays.asList(
            Pattern.compile("^10\\."),
            Pattern.compile("^172\\.(1[6-9]|2[0-9]|3[01])\\."),
            Pattern.compile("^192\\.168\\."),
            Pattern.compile("^127\\."),
            Pattern.compile("^0\\."),
            Pattern.compile("^169\\.254\\."),
            Pattern.compile("^fc00:", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^fe80:", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^::1$"),
            Pattern.compile("^::$")
        );

        this.blockedPorts = Arrays.asList(
            22, 23, 25, 53, 110, 143, 993, 995,
            3306, 5432, 6379, 11211, 27017,
            5984, 9200, 9300,
            8080, 8443, 9000, 9090,
            3000, 4000, 5000, 8000, 8888
        );
    }

    public boolean isValidUrl(String urlString) {
        try {
            URL parsedUrl = new URL(urlString);
            
            if (blockedProtocols.contains(parsedUrl.getProtocol().toLowerCase() + ":")) {
                return false;
            }

            String hostname = parsedUrl.getHost().toLowerCase();
            
            if (blockedDomains.stream().anyMatch(hostname::contains)) {
                return false;
            }

            if (isPrivateIP(hostname)) {
                return false;
            }

            int port = parsedUrl.getPort() != -1 ? parsedUrl.getPort() : 
                      ("https".equals(parsedUrl.getProtocol()) ? 443 : 80);
            if (blockedPorts.contains(port)) {
                return false;
            }

            if (containsSuspiciousHostname(hostname)) {
                return false;
            }

            if (isUrlShortener(hostname)) {
                return false;
            }

            return true;
        } catch (Exception error) {
            return false;
        }
    }

    private boolean isPrivateIP(String hostname) {
        try {
            InetAddress addr = InetAddress.getByName(hostname);
            String ip = addr.getHostAddress();
            return privateIPRanges.stream().anyMatch(range -> range.matcher(ip).find());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean containsSuspiciousHostname(String hostname) {
        List<Pattern> suspiciousPatterns = Arrays.asList(
            Pattern.compile("^admin", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^api", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^internal", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^private", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^test", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^dev", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^staging", Pattern.CASE_INSENSITIVE),
            Pattern.compile("^local", Pattern.CASE_INSENSITIVE),
            Pattern.compile("\\.local$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("\\.internal$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("\\.corp$", Pattern.CASE_INSENSITIVE),
            Pattern.compile("\\b(localhost|loopback)\\b", Pattern.CASE_INSENSITIVE)
        );
        
        return suspiciousPatterns.stream().anyMatch(pattern -> pattern.matcher(hostname).find());
    }

    private boolean isUrlShortener(String hostname) {
        List<String> shorteners = Arrays.asList(
            "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"
        );
        
        return shorteners.stream().anyMatch(hostname::equals);
    }
}
