package services;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.List;
import java.time.Duration;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class MetadataExtractor {
    private final UrlValidator urlValidator;
    private final HttpClient httpClient;

    public MetadataExtractor() {
        this.urlValidator = new UrlValidator();
        
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    }

    public Map<String, Object> extractMetadata(String url) throws Exception {
        if (!urlValidator.isValidUrl(url)) {
            throw new Exception("URL validation failed - blocked by security policy");
        }

        try {
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(5))
                .header("User-Agent", "MetadataSnapshot/1.0 (+https://example.com/bot)")
                .GET()
                .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            String contentType = response.headers().firstValue("content-type").orElse("");
            if (!contentType.contains("text/html") && !contentType.contains("application/xhtml")) {
                throw new Exception("Invalid content type - only HTML content is supported");
            }

            String html = response.body();

            Map<String, Object> metadata = new HashMap<>();
            metadata.put("title", sanitizeMetadata(extractTitle(html)));
            metadata.put("description", sanitizeMetadata(extractMetaContent(html, "name=\"description\"")));
            metadata.put("ogTitle", sanitizeMetadata(extractMetaContent(html, "property=\"og:title\"")));
            metadata.put("ogDescription", sanitizeMetadata(extractMetaContent(html, "property=\"og:description\"")));
            metadata.put("ogImage", sanitizeMetadata(extractMetaContent(html, "property=\"og:image\"")));
            metadata.put("headers", filterHeaders(response.headers().map()));
            metadata.put("statusCode", response.statusCode());
            metadata.put("finalUrl", response.uri().toString());

            return metadata;
        } catch (IOException error) {
            if (error.getMessage().contains("nodename nor servname provided")) {
                throw new Exception("Domain not found");
            } else if (error.getMessage().contains("Connection refused")) {
                throw new Exception("Connection refused");
            } else if (error.getMessage().contains("timeout")) {
                throw new Exception("Request timeout");
            }
            throw new Exception("Failed to fetch metadata: " + error.getMessage());
        }
    }

    private String sanitizeMetadata(String value) {
        if (value == null || value.isEmpty()) return null;
        return value.trim().substring(0, Math.min(value.length(), 500));
    }

    private String extractTitle(String html) {
        Pattern pattern = Pattern.compile("<title[^>]*>([^<]*)</title>", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(html);
        return matcher.find() ? matcher.group(1) : null;
    }

    private String extractMetaContent(String html, String attribute) {
        Pattern pattern = Pattern.compile("<meta[^>]*" + attribute + "[^>]*content=[\"']([^\"']*)[\"'][^>]*>", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(html);
        return matcher.find() ? matcher.group(1) : null;
    }

    private Map<String, Object> filterHeaders(Map<String, java.util.List<String>> headers) {
        Map<String, Object> safeHeaders = new HashMap<>();
        List<String> allowedHeaders = Arrays.asList(
            "content-type", "content-length", "last-modified",
            "cache-control", "expires", "etag"
        );
        
        allowedHeaders.forEach(header -> {
            if (headers.containsKey(header)) {
                safeHeaders.put(header, headers.get(header).get(0));
            }
        });
        
        return safeHeaders;
    }

    public Map<String, Object> checkUrlAvailability(String url) throws Exception {
        if (!urlValidator.isValidUrl(url)) {
            throw new Exception("URL validation failed - blocked by security policy");
        }

        try {
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(2))
                .header("User-Agent", "MetadataSnapshot/1.0 (+https://example.com/bot)")
                .method("HEAD", HttpRequest.BodyPublishers.noBody())
                .build();
            
            HttpResponse<Void> response = httpClient.send(request, HttpResponse.BodyHandlers.discarding());
            
            Map<String, Object> result = new HashMap<>();
            result.put("available", true);
            result.put("status", response.statusCode());
            result.put("finalUrl", response.uri().toString());
            return result;
        } catch (IOException error) {
            Map<String, Object> result = new HashMap<>();
            result.put("available", false);
            result.put("error", error.getMessage());
            return result;
        }
    }
}
