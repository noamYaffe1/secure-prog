package test;

import services.UrlValidator;
import services.MetadataExtractor;
import java.util.Map;

public class SSRFTest {
    public static void main(String[] args) {
        testUrlValidator();
        testRedirectBypass();
    }

    private static void testUrlValidator() {
        System.out.println("=== Testing UrlValidator ===");
        UrlValidator validator = new UrlValidator();
        
        // Test cases that should be blocked
        String[] blockedUrls = {
            "http://127.0.0.1:8080",
            "https://localhost:3000",
            "https://169.254.169.254/latest/meta-data/",
            "file:///etc/passwd",
            "https://admin.internal.com"
        };
        
        for (String url : blockedUrls) {
            boolean isValid = validator.isValidUrl(url);
            System.out.println("URL: " + url + " -> Valid: " + isValid + (isValid ? " ❌ SHOULD BE BLOCKED" : " ✅ Correctly blocked"));
        }
        
        // Test cases that should be allowed
        String[] allowedUrls = {
            "https://httpbin.org/get",
            "https://example.com",
            "https://google.com"
        };
        
        for (String url : allowedUrls) {
            boolean isValid = validator.isValidUrl(url);
            System.out.println("URL: " + url + " -> Valid: " + isValid + (isValid ? " ✅ Correctly allowed" : " ❌ SHOULD BE ALLOWED"));
        }
    }

    private static void testRedirectBypass() {
        System.out.println("\n=== Testing Redirect Bypass ===");
        MetadataExtractor extractor = new MetadataExtractor();
        
        // This should pass initial validation but redirect to localhost
        String redirectUrl = "https://httpbin.org/redirect-to?url=http://127.0.0.1:8080";
        
        try {
            System.out.println("Testing redirect bypass URL: " + redirectUrl);
            Map<String, Object> result = extractor.extractMetadata(redirectUrl);
            System.out.println("❌ VULNERABILITY: Request succeeded!");
            System.out.println("Final URL: " + result.get("finalUrl"));
            System.out.println("Status: " + result.get("statusCode"));
        } catch (Exception e) {
            System.out.println("✅ Request blocked: " + e.getMessage());
        }
    }
}
