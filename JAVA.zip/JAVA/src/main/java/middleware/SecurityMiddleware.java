package middleware;

import java.security.MessageDigest;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

public class SecurityMiddleware {
    private final Map<String, RequestTracking> requestTracking;

    public SecurityMiddleware() {
        this.requestTracking = new ConcurrentHashMap<>();
    }

    public void securityHeaders(Map<String, String> headers) {
        headers.put("X-Content-Type-Options", "nosniff");
        headers.put("X-Frame-Options", "DENY");
        headers.put("X-XSS-Protection", "1; mode=block");
        headers.put("Referrer-Policy", "strict-origin-when-cross-origin");
        headers.put("Content-Security-Policy", "default-src 'self'");
    }

    public void trackRequest(String clientIP, String userAgent, String url) {
        String fingerprint;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update((clientIP + userAgent).getBytes());
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            fingerprint = sb.toString();
        } catch (Exception e) {
            fingerprint = "unknown";
        }

        if (!requestTracking.containsKey(fingerprint)) {
            requestTracking.put(fingerprint, new RequestTracking());
        }

        RequestTracking tracking = requestTracking.get(fingerprint);
        tracking.requests++;
        tracking.lastSeen = System.currentTimeMillis();
        
        if (url != null) {
            tracking.urls.add(url);
        }

        int recentRequests = tracking.requests;
        int uniqueUrls = tracking.urls.size();

        if (recentRequests > 50 || uniqueUrls > 20) {
            System.out.println("[SECURITY] Suspicious activity detected from " + fingerprint + ": " + recentRequests + " requests, " + uniqueUrls + " unique URLs");
        }
    }

    public boolean limitRequestSize(long contentLength, int maxSize) {
        if (contentLength > maxSize) {
            return false;
        }
        return true;
    }

    public void cleanup() {
        long now = System.currentTimeMillis();
        long maxAge = 24 * 60 * 60 * 1000;

        requestTracking.entrySet().removeIf(entry -> 
            now - entry.getValue().lastSeen > maxAge);
    }

    private static class RequestTracking {
        int requests = 0;
        long firstSeen = System.currentTimeMillis();
        long lastSeen = System.currentTimeMillis();
        Set<String> urls = new HashSet<>();
    }
}
