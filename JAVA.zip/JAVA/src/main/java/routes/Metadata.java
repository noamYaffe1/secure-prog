package routes;

import services.MetadataExtractor;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.time.Instant;
import java.net.URI;

public class Metadata {
    private final MetadataExtractor metadataExtractor;
    private final Map<String, RateLimitData> rateLimitMap;
    private final long RATE_LIMIT_WINDOW = 60000;
    private final int RATE_LIMIT_MAX_REQUESTS = 10;

    public Metadata() {
        this.metadataExtractor = new MetadataExtractor();
        this.rateLimitMap = new ConcurrentHashMap<>();
    }

    public Map<String, Object> extract(String url, String clientIP) {
        Map<String, Object> response = new HashMap<>();
        
        if (!rateLimit(clientIP)) {
            response.put("error", "Rate limit exceeded. Try again later.");
            response.put("status", 429);
            return response;
        }

        if (!validateUrl(url)) {
            response.put("error", "Validation failed");
            response.put("details", "Only HTTPS URLs are allowed");
            response.put("status", 400);
            return response;
        }

        try {
            Map<String, Object> metadata = metadataExtractor.extractMetadata(url);
            
            System.out.println("[" + Instant.now().toString() + "] Metadata extracted for: " + url);
            
            response.put("success", true);
            response.put("data", metadata);
            response.put("extractedAt", Instant.now().toString());
            response.put("status", 200);
            
            return response;
        } catch (Exception error) {
            System.err.println("[" + Instant.now().toString() + "] Error extracting metadata: " + error.getMessage());
            response.put("error", error.getMessage());
            response.put("success", false);
            response.put("status", 400);
            return response;
        }
    }

    public Map<String, Object> check(String url, String clientIP) {
        Map<String, Object> response = new HashMap<>();
        
        if (!rateLimit(clientIP)) {
            response.put("error", "Rate limit exceeded. Try again later.");
            response.put("status", 429);
            return response;
        }

        if (!validateUrl(url)) {
            response.put("error", "Validation failed");
            response.put("details", "Only HTTPS URLs are allowed");
            response.put("status", 400);
            return response;
        }

        try {
            Map<String, Object> result = metadataExtractor.checkUrlAvailability(url);
            
            System.out.println("[" + Instant.now().toString() + "] URL availability check for: " + url);
            
            response.put("success", true);
            response.put("data", result);
            response.put("status", 200);
            
            return response;
        } catch (Exception error) {
            System.err.println("[" + Instant.now().toString() + "] Error checking URL: " + error.getMessage());
            response.put("error", error.getMessage());
            response.put("success", false);
            response.put("status", 400);
            return response;
        }
    }

    private boolean rateLimit(String clientIP) {
        long now = System.currentTimeMillis();
        
        if (!rateLimitMap.containsKey(clientIP)) {
            rateLimitMap.put(clientIP, new RateLimitData(1, now + RATE_LIMIT_WINDOW));
            return true;
        }
        
        RateLimitData client = rateLimitMap.get(clientIP);
        
        if (now > client.resetTime) {
            client.requests = 1;
            client.resetTime = now + RATE_LIMIT_WINDOW;
            return true;
        }
        
        if (client.requests >= RATE_LIMIT_MAX_REQUESTS) {
            return false;
        }
        
        client.requests++;
        return true;
    }

    private boolean validateUrl(String url) {
        if (url == null || url.length() > 2048) {
            return false;
        }
        
        try {
            URI parsedUrl = URI.create(url);
            return "https".equals(parsedUrl.getScheme());
        } catch (Exception e) {
            return false;
        }
    }

    private static class RateLimitData {
        int requests;
        long resetTime;

        RateLimitData(int requests, long resetTime) {
            this.requests = requests;
            this.resetTime = resetTime;
        }
    }
}
