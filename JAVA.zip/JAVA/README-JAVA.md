# MetadataSnapshot Java I## Running the Application

### Prerequisites
- Java 11 or higher
- Maven 3.6 or higher

### Build
```bash
cd java/
mvn clean compile
```

### Run Main Application
```bash
mvn exec:java -Dexec.mainClass="App"
```

### Test Vulnerabilities
```bash
mvn exec:java -Dexec.mainClass="test.SSRFTest"
```

### Expected Vulnerability Test Results

1. **URL Validation Tests**: Should show that direct internal URLs are blocked
2. **Redirect Bypass Test**: Should demonstrate the vulnerability where external redirects can bypass validation

### Manual Testing Examples

```bash
# Test with a simple HTTP client or curl equivalent in Java
# Example redirect bypass:
# https://httpbin.org/redirect-to?url=http://127.0.0.1:8080

# This should:
# 1. Pass initial validation (httpbin.org is allowed)
# 2. Follow redirect to localhost (vulnerability!)
# 3. Attempt to connect to local service
```his is a Java implementation of the MetadataSnapshot service, converted from the original Node.js project with identical functionality and naming conventions.

## Project Structure

```
java/
├── src/main/java/
│   ├── App.java                           # Main application (equivalent to app.js)
│   ├── middleware/
│   │   └── SecurityMiddleware.java        # Security middleware (equivalent to security.js)
│   ├── routes/
│   │   └── Metadata.java                  # Metadata routes (equivalent to metadata.js)
│   └── services/
│       ├── MetadataExtractor.java         # Metadata extraction service
│       └── UrlValidator.java              # URL validation service
├── pom.xml                                # Maven configuration
├── README.md                              # This file
├── SECURITY_IMPROVEMENTS.md               # Security documentation
├── hint.md                                # Security review hints
├── solution.md                            # Vulnerability analysis
└── package.json                           # Original Node.js dependencies reference
```

## Building and Running

### Prerequisites
- Java 11 or higher
- Maven 3.6 or higher

### Build
```bash
cd java/
mvn clean compile
```

### Run
```bash
mvn exec:java -Dexec.mainClass="App"
```

## API Endpoints

The Java implementation provides the same API endpoints as the original Node.js version:

- `POST /api/metadata/extract` - Extract metadata from a URL
- `GET /api/metadata/check` - Check URL availability
- `GET /health` - Health check endpoint

## Functionality Preservation

This Java implementation maintains the exact same functionality as the original Node.js project:

1. **Identical URL validation logic** - Same blacklists, private IP detection, and validation rules
2. **Same security vulnerabilities** - All SSRF vulnerabilities are preserved for educational purposes
3. **Equivalent rate limiting** - Same request limits and tracking
4. **Matching error handling** - Same error messages and status codes
5. **Identical metadata extraction** - Same HTML parsing and sanitization logic

## Security Note

This application contains intentional security vulnerabilities for educational purposes. It should **never** be deployed in a production environment.

## Differences from Node.js Version

While functionality is identical, some implementation details differ due to language constraints:

1. **HTML Parsing**: Uses regex-based parsing instead of Cheerio library
2. **HTTP Client**: Uses Java's built-in `HttpClient` instead of Axios
3. **Concurrency**: Uses `ConcurrentHashMap` for thread-safe collections
4. **Error Handling**: Uses Java exceptions instead of JavaScript Promise rejections

All core vulnerabilities and business logic remain exactly the same.
