# MetadataSnapshot

## Overview
MetadataSnapshot is a microservice that extracts metadata and generates previews from web pages. It's used by internal teams to gather information about external URLs, including title, description, images, and other OpenGraph metadata.

## Architecture
- Node.js/Express API service
- Uses cheerio for HTML parsing
- Redis for caching responses
- Basic URL validation and sanitization

## Functionality
1. Submit URLs for metadata extraction
2. Retrieve page titles, descriptions, and OpenGraph tags
3. Cache responses for improved performance
4. Support for custom metadata extraction rules

## Training Goal
This application helps developers understand the risks of making HTTP requests to user-provided URLs. The review focuses on identifying Server-Side Request Forgery (SSRF) vulnerabilities that could allow attackers to access internal network resources or perform port scanning. 
