# SSRF Vulnerability Analysis - Code Review Approach

## Executive Summary
This code review reveals multiple SSRF vulnerabilities in the MetadataSnapshot service. While the application implements several security controls, critical gaps in URL validation and redirect handling allow attackers to access internal network resources.

# SSRF Vulnerability Analysis - Java Implementation Code Review

## Executive Summary
This code review reveals SSRF vulnerabilities in the Java MetadataSnapshot service. While the application implements several security controls including DNS resolution validation, critical gaps in redirect handling allow attackers to access internal network resources.

## Code Review Findings

### Entry Point Analysis

#### File: `src/main/java/routes/Metadata.java`
Starting our review at the main API endpoints:

```java
public Map<String, Object> extract(String url, String clientIP) {
    // ... validation logic
    Map<String, Object> metadata = metadataExtractor.extractMetadata(url);
```

**Analysis**: The `/extract` endpoint accepts user-provided URLs and passes them to `metadataExtractor.extractMetadata()`. Let's trace this flow.

#### URL Validation Layer

The `validateUrl` method in `Metadata.java` performs initial validation:

```java
private boolean validateUrl(String url) {
    if (url == null || url.length() > 2048) {
        return false;
    }
    
    try {
        URI parsedUrl = URI.create(url);
        return "https".equals(parsedUrl.getScheme());
    } catch (Exception e) {
        return false;
    }
}
```

**Finding**: This only validates URL format and enforces HTTPS. No validation of destination hosts or internal IP ranges at this layer.

### Core Vulnerability Analysis

#### File: `src/main/java/services/MetadataExtractor.java`

Following the flow to the main processing function:

```java
public Map<String, Object> extractMetadata(String url) throws Exception {
    if (!urlValidator.isValidUrl(url)) {
        throw new Exception("URL validation failed - blocked by security policy");
    }

    try {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .timeout(Duration.ofSeconds(5))
            .header("User-Agent", "MetadataSnapshot/1.0 (+https://example.com/bot)")
            .GET()
            .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
```

**Critical Finding**: The function calls `urlValidator.isValidUrl()` for validation, then makes the HTTP request with Java's `HttpClient`. The HTTP client is configured with `.followRedirects(HttpClient.Redirect.NORMAL)` but there's **no validation of the final URL after redirects**.

#### File: `src/main/java/services/UrlValidator.java`

Examining the URL validation logic:

```java
public boolean isValidUrl(String urlString) {
    try {
        URL parsedUrl = new URL(urlString);
        
        // Check protocol blacklist
        if (blockedProtocols.contains(parsedUrl.getProtocol().toLowerCase() + ":")) {
            return false;
        }

        String hostname = parsedUrl.getHost().toLowerCase();
        
        // Check domain blacklist
        if (blockedDomains.stream().anyMatch(hostname::contains)) {
            return false;
        }

        // Check for private IP ranges
        if (isPrivateIP(hostname)) {
            return false;
        }
        // ... more checks
    }
}

private boolean isPrivateIP(String hostname) {
    try {
        InetAddress addr = InetAddress.getByName(hostname);
        String ip = addr.getHostAddress();
        return privateIPRanges.stream().anyMatch(range -> range.matcher(ip).find());
    } catch (Exception e) {
        return false;
    }
}
```

**Key Observations**:
1. ✅ Implements comprehensive blacklists for protocols, domains, and IP ranges
2. ✅ Blocks common internal hosts and cloud metadata endpoints  
3. ✅ **Performs DNS resolution validation** - Uses `InetAddress.getByName()` to resolve hostnames to IPs
4. ❌ **Critical Gap**: Only validates the **initial URL**, not the final destination after redirects
5. ❌ **Exception Handling Issue**: DNS resolution errors return `false` (allowing invalid URLs through)

## Vulnerability Details & Attack Vectors

### 1. Redirect Chain Bypass (High Severity)

**Root Cause**: In `MetadataExtractor.java`, the application validates the initial URL but allows Java's `HttpClient` to follow redirects without re-validating the final destination.

**Attack Flow**:
```
Initial URL: https://httpbin.org/redirect-to?url=http://127.0.0.1:8080
    ↓ (passes urlValidator.isValidUrl())
    ↓ HttpClient.send() follows redirect
Final URL: http://127.0.0.1:8080 (never validated!)
```

**Exploitation**:
```bash
# Bypass localhost restrictions via redirect
curl -X POST http://localhost:8080/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://httpbin.org/redirect-to?url=http://127.0.0.1:8080"}'

# Access AWS metadata via redirect
curl -X POST http://localhost:8080/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://legitimate-site.com/redirect?target=http://169.254.169.254/latest/meta-data/"}'
```

### 2. DNS Resolution Exception Bypass (Medium Severity)

**Root Cause**: The `UrlValidator.java` performs DNS resolution validation, but catches all exceptions and returns `false` (allowing the URL), potentially allowing malformed hostnames or DNS errors to bypass validation.

**Code Analysis**: In `UrlValidator.java`, the `isPrivateIP()` method:
```java
private boolean isPrivateIP(String hostname) {
    try {
        InetAddress addr = InetAddress.getByName(hostname);
        String ip = addr.getHostAddress();
        return privateIPRanges.stream().anyMatch(range -> range.matcher(ip).find());
    } catch (Exception e) {
        return false; // ❌ Returns false on DNS errors - allows URL through!
    }
}
```

**Attack Flow**:
```
1. Provide malformed hostname that causes DNS exception
2. Exception caught, method returns false (not private IP)
3. URL validation continues and may pass
4. HTTP request made to potentially dangerous destination
```

**Exploitation**:
```bash
# Test with malformed hostnames that might cause DNS exceptions
curl -X POST http://localhost:8080/api/metadata/extract \
  -H "Content-Type: application/json" \
  -d '{"url": "https://malformed..hostname..local"}'
```

### 3. Time-of-Check vs Time-of-Use (TOCTOU) Attack (Medium Severity)

**Root Cause**: DNS resolution happens during validation, but there's a time gap before the actual HTTP request. DNS records can change between validation and request.

**Attack Flow**:
```
1. Validation time: evil-domain.com → 1.2.3.4 (public IP, passes validation)
2. Time gap (even milliseconds)
3. Request time: evil-domain.com → 127.0.0.1 (internal IP, request goes here)
```

**Code Fix Required**: Validate the resolved IP at request time:
```java
// In MetadataExtractor.java, before making HTTP request
String finalHostname = URI.create(url).getHost();
if (!urlValidator.isValidResolvedIP(finalHostname)) {
    throw new Exception("Final destination blocked by security policy");
}
```

## Impact Assessment

### Accessible Internal Resources
1. **Localhost services**: Development servers, admin panels, APIs
2. **Internal network hosts**: Databases, application servers, monitoring systems  
3. **Cloud metadata services**: AWS/GCP/Azure instance metadata
4. **Container orchestration**: Kubernetes API, Docker daemon
5. **Network infrastructure**: Routers, switches, management interfaces

### Attack Scenarios
1. **Credential theft**: Access cloud metadata for IAM credentials
2. **Service enumeration**: Port scan internal network via timing attacks
3. **Data exfiltration**: Access internal APIs and databases
4. **Privilege escalation**: Access admin interfaces and configuration endpoints
5. **Infrastructure mapping**: Discover internal network topology

## Remediation Recommendations

### Immediate Fixes (High Priority)

1. **Add redirect validation** in `MetadataExtractor.java`:
```java
// After HTTP request, validate final URL
URI finalUri = response.uri();
if (!urlValidator.isValidUrl(finalUri.toString())) {
    throw new Exception("Final redirect destination blocked by security policy");
}
```

2. **Fix DNS exception handling** in `UrlValidator.java`:
```java
private boolean isPrivateIP(String hostname) {
    try {
        InetAddress addr = InetAddress.getByName(hostname);
        String ip = addr.getHostAddress();
        return privateIPRanges.stream().anyMatch(range -> range.matcher(ip).find());
    } catch (Exception e) {
        return true; // ✅ Block on DNS errors for security
    }
}
```

3. **Enhance IPv6 validation** to cover all localhost representations
4. **Add request-time DNS validation** to prevent TOCTOU attacks

### Strategic Improvements (Medium Priority)

1. **Replace blacklists with allowlists** for trusted domains
2. **Implement network-level egress filtering**
3. **Deploy service in isolated network segment**
4. **Add comprehensive logging and monitoring**

### Defense in Depth (Low Priority)

1. **Container sandboxing** with restricted network access
2. **Request signing** for authenticated URL fetching
3. **Content validation** beyond just content-type checking
4. **Rate limiting enhancements** with distributed cache

## Java-Specific Security Considerations

### HTTP Client Configuration
The Java implementation uses `HttpClient` with specific security implications:

```java
this.httpClient = HttpClient.newBuilder()
    .connectTimeout(Duration.ofSeconds(5))
    .followRedirects(HttpClient.Redirect.NORMAL)  // ❌ Vulnerable to redirect bypass
    .build();
```

**Recommended secure configuration**:
```java
this.httpClient = HttpClient.newBuilder()
    .connectTimeout(Duration.ofSeconds(5))
    .followRedirects(HttpClient.Redirect.NEVER)  // ✅ Disable auto-redirects
    .build();
```

### Exception Handling Security
Java's exception handling can create security vulnerabilities if not properly implemented:

```java
// Current vulnerable pattern
catch (Exception e) {
    return false; // Fails open - allows through on errors
}

// Secure pattern
catch (Exception e) {
    log.warn("DNS resolution failed for hostname: " + hostname, e);
    return true; // Fails closed - blocks on errors
}
```
